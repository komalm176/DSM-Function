using Dapper;
using EmailScanProcessor.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace EmailScanProcessor.Services;

public sealed class EmailDocumentRepository : IEmailDocumentRepository
{
    private readonly string _connectionString;
    private readonly ILogger<EmailDocumentRepository> _logger;

    public EmailDocumentRepository(string connectionString, ILogger<EmailDocumentRepository> logger)
    {
        _connectionString = connectionString;
        _logger = logger;
    }

    public async Task<IReadOnlyList<EmailDocument>> GetPendingDocumentsAsync(
        int batchSize,
        int ageThresholdHours,
        CancellationToken ct)
    {
        const string sql = @"
            SELECT TOP (@BatchSize)
                Id,
                EmailMessageId,
                EmailAttachmentPath,
                EmailStatus,
                CreatedOn
            FROM dbo.EmailDocuments
            WHERE EmailStatus = @ScanPendingStatus
              AND EmailAttachmentPath IS NOT NULL
              AND CreatedOn < DATEADD(HOUR, -@AgeHours, SYSUTCDATETIME())
            ORDER BY CreatedOn DESC;";

        await using var conn = new SqlConnection(_connectionString);
        var cmd = new CommandDefinition(
            sql,
            new
            {
                BatchSize = batchSize,
                AgeHours = ageThresholdHours,
                ScanPendingStatus = EmailStatuses.ScanPending
            },
            cancellationToken: ct);

        var rows = await conn.QueryAsync<EmailDocument>(cmd);
        var list = rows.AsList();
        _logger.LogInformation("Fetched {Count} {Status} document(s) older than {Hours}h",
            list.Count, EmailStatuses.ScanPending, ageThresholdHours);
        return list;
    }

    public async Task<bool> UpdateAfterProcessingAsync(
        long id,
        string newStatus,
        string newAttachmentPath,
        CancellationToken ct)
    {
        const string sql = @"
            UPDATE dbo.EmailDocuments
               SET EmailStatus = @NewStatus,
                   EmailAttachmentPath = @NewPath,
                   ModifiedOn = SYSUTCDATETIME(),
                   ModifiedBy = 'EmailScanProcessor'
             WHERE Id = @Id
               AND EmailStatus = @ScanPendingStatus;";

        await using var conn = new SqlConnection(_connectionString);
        var cmd = new CommandDefinition(
            sql,
            new
            {
                Id = id,
                NewStatus = newStatus,
                NewPath = newAttachmentPath,
                ScanPendingStatus = EmailStatuses.ScanPending
            },
            cancellationToken: ct);

        var affected = await conn.ExecuteAsync(cmd);
        if (affected == 0)
        {
            _logger.LogWarning(
                "Update for Id={Id} affected 0 rows (status may have already changed).", id);
            return false;
        }
        return true;
    }
}
