# EmailScanProcessor

Timer-triggered Azure Function (.NET 10, isolated worker) that:

1. Polls `dbo.EmailDocuments` for rows where `EmailStatus = 'ScanPending'` and `CreatedOn < now - 4h`.
2. Pulls up to 100 rows per cycle (configurable).
3. For each row, lists every blob under `email-scanpending/<EmailAttachmentPath>/` and checks the Defender for Storage scan-result blob index tag.
4. If **all** blobs in the folder have `Malware Scanning scan result = No threats found`, moves the folder to `email-processed/<same-name>/` and updates `EmailStatus = 'ReadyForUpload'` (by `Id`).
5. If any blob is `Malicious` or has no scan tag yet, the row is skipped this cycle.

---

## Required Azure prerequisites

Defender for Storage settings on `sftpdatalakedev01` are already configured — "Store scan results as blob index tags" is checked and on-upload scanning is on. The storage account has Hierarchical Namespace enabled, so one extra step is needed for tags to actually appear on blobs:

### 1. Register the HNS blob-tags preview feature on the subscription

```bash
# One-time, per subscription
az feature register \
  --namespace Microsoft.Storage \
  --name BlobIndexForHns \
  --subscription 8988b176-9eb0-4e96-8956-5e4bb60530cf

# Check status (wait until "Registered")
az feature show \
  --namespace Microsoft.Storage \
  --name BlobIndexForHns \
  --subscription 8988b176-9eb0-4e96-8956-5e4bb60530cf \
  --query properties.state

# Propagate the registration to the resource provider
az provider register \
  --namespace Microsoft.Storage \
  --subscription 8988b176-9eb0-4e96-8956-5e4bb60530cf
```

### 2. Verify

Upload any file to `email-scanpending`. Within a minute or two, open its **Blob index tags** in the portal — you should see `Malware Scanning scan result = No threats found` and `Malware Scanning scan time = <timestamp>`. If you don't see the tags after a few minutes, the preview feature isn't fully propagated yet — wait or re-check the registration state.

### 3. RBAC for the Function's identity (or whatever runs it)

When you move from connection strings to Managed Identity later, the identity needs:
- `Storage Blob Data Contributor` on `sftpdatalakedev01` (read/move blobs and read tags).
- `db_datareader` + UPDATE on `dbo.EmailDocuments` in the SQL database.

For now the project uses connection strings as you specified.

---

## Local dev

```bash
# Tooling
dotnet --list-sdks                 # must include 10.x
func --version                     # Azure Functions Core Tools v4

# Restore + run
cd EmailScanProcessor
dotnet restore
func start
```

Fill in `local.settings.json` with real `SqlConnectionString` and `BlobStorageConnectionString` values before running.

---

## Configuration keys

| Key | Purpose | Default |
|---|---|---|
| `SqlConnectionString` | SQL Server connection | — |
| `BlobStorageConnectionString` | Storage account connection string | — |
| `ScanProcessor:ScheduleCron` | NCRONTAB schedule | `0 */5 * * * *` (every 5 min) |
| `ScanProcessor:SourceContainer` | Where ScanPending folders live | `email-scanpending` |
| `ScanProcessor:DestinationContainer` | Where clean folders go | `email-processed` |
| `ScanProcessor:BatchSize` | Rows per cycle | `100` |
| `ScanProcessor:AgeThresholdHours` | Only pick rows older than this | `4` |
| `ScanProcessor:UseAdlsRename` | Use ADLS Gen2 rename (true) vs copy+delete (false) | `true` |

---

## Behavior reference

| Folder state | Action | SQL change |
|---|---|---|
| All blobs tagged `No threats found` | Move to `email-processed/<folder>/` | `EmailStatus = 'ReadyForUpload'` |
| Any blob tagged `Malicious` | Skip — log warning | None |
| Any blob has no scan tag yet | Skip — will retry next cycle | None |
| Folder empty | Skip — log warning | None |

The row stays `ScanPending` for malicious / unscanned cases. If you later want a `Quarantined` terminal status for malicious folders, add it in `EmailScanProcessor.RunAsync` under the `AnyMalicious` branch.

---

## Deployment notes

- Plan: Functions v4 runtime, **isolated worker**, .NET 10. **Not Linux Consumption** (use Flex Consumption or any Windows plan).
- Required app settings: `FUNCTIONS_WORKER_RUNTIME=dotnet-isolated`, plus all keys in the table above.
- The function timeout in `host.json` is 10 minutes — increase only if a batch of 100 with large folders consistently runs longer.

---

## Things deliberately deferred

- **Concurrency lock** — if two instances run, both can grab the same rows. Skipped per request; add a `Processing` intermediate state if you ever scale out.
- **Malicious-row terminal state** — currently just stays `ScanPending`. Add a `Quarantined` enum value when ready.
- **Managed identity** — using connection strings for now per the spec; swap to `DefaultAzureCredential` later.
