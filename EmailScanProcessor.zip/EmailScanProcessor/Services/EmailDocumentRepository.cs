using Dapper;
using EmailScanProcessor.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace EmailScanProcessor.Services;

public sealed class EmailDocumentRepository : IEmailDocumentRepository
{
    private readonly string _connectionString;
    private readonly ILogger<EmailDocumentRepository> _logger;

    public EmailDocumentRepository(string connectionString, ILogger<EmailDocumentRepository> logger)
    {
        _connectionString = connectionString;
        _logger = logger;
    }

    public async Task<IReadOnlyList<EmailDocument>> GetPendingDocumentsAsync(
        int batchSize,
        int ageThresholdHours,
        CancellationToken ct)
    {
        const string sql = @"
            SELECT TOP (@BatchSize)
                Id,
                EmailMessageId,
                EmailAttachmentPath,
                EmailStatus,
                CreatedOn
            FROM dbo.EmailDocuments
            WHERE EmailStatus = 'ScanPending'
              AND EmailAttachmentPath IS NOT NULL
              AND CreatedOn < DATEADD(HOUR, -@AgeHours, SYSUTCDATETIME())
            ORDER BY CreatedOn ASC;";

        await using var conn = new SqlConnection(_connectionString);
        var cmd = new CommandDefinition(
            sql,
            new { BatchSize = batchSize, AgeHours = ageThresholdHours },
            cancellationToken: ct);

        var rows = await conn.QueryAsync<EmailDocument>(cmd);
        var list = rows.AsList();
        _logger.LogInformation("Fetched {Count} ScanPending document(s) older than {Hours}h", list.Count, ageThresholdHours);
        return list;
    }

    public async Task MarkReadyForUploadAsync(long id, CancellationToken ct)
    {
        const string sql = @"
            UPDATE dbo.EmailDocuments
               SET EmailStatus = 'ReadyForUpload'
             WHERE Id = @Id
               AND EmailStatus = 'ScanPending';";

        await using var conn = new SqlConnection(_connectionString);
        var cmd = new CommandDefinition(sql, new { Id = id }, cancellationToken: ct);
        var affected = await conn.ExecuteAsync(cmd);

        if (affected == 0)
        {
            _logger.LogWarning("Status update for Id={Id} affected 0 rows (status may have changed)", id);
        }
    }
}
