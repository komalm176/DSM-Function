namespace EmailScanProcessor.Models;

public sealed class EmailDocument
{
    public long Id { get; set; }
    public string EmailMessageId { get; set; } = string.Empty;
    public string? EmailAttachmentPath { get; set; }
    public string EmailStatus { get; set; } = string.Empty;
    public DateTime CreatedOn { get; set; }
}
