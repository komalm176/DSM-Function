using Azure.Storage.Blobs;
using EmailScanProcessor.Models;
using EmailScanProcessor.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

var builder = FunctionsApplication.CreateBuilder(args);

// Application Insights
builder.Services
    .AddApplicationInsightsTelemetryWorkerService()
    .ConfigureFunctionsApplicationInsights();

// Options
builder.Services
    .AddOptions<ScanProcessorOptions>()
    .Bind(builder.Configuration.GetSection(ScanProcessorOptions.SectionName))
    .ValidateDataAnnotations();

// Storage clients
var blobConn = builder.Configuration["BlobStorageConnectionString"]
    ?? throw new InvalidOperationException("BlobStorageConnectionString is missing.");

builder.Services.AddSingleton(_ => new BlobServiceClient(blobConn));

// SQL repository
var sqlConn = builder.Configuration["SqlConnectionString"]
    ?? throw new InvalidOperationException("SqlConnectionString is missing.");

builder.Services.AddSingleton<IEmailDocumentRepository>(sp =>
    new EmailDocumentRepository(sqlConn, sp.GetRequiredService<ILogger<EmailDocumentRepository>>()));

// Application services
builder.Services.AddSingleton<IPdfConverter, PdfConverter>();
builder.Services.AddSingleton<IBlobScanService, BlobScanService>();
builder.Services.AddSingleton<IBlobProcessorService, BlobProcessorService>();

var host = builder.Build();

// Register Syncfusion license (if configured). Without a key, Syncfusion runs in trial
// mode and adds a watermark to generated PDFs.
var options = host.Services.GetRequiredService<IOptions<ScanProcessorOptions>>().Value;
if (!string.IsNullOrWhiteSpace(options.SyncfusionLicenseKey))
{
    Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense(options.SyncfusionLicenseKey);
}

await host.RunAsync();
