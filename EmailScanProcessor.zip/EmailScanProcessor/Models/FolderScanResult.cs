namespace EmailScanProcessor.Models;

public enum FolderScanState
{
    AllClean,
    AnyMalicious,
    AnyUnscanned,
    Empty
}

public sealed class FolderScanResult
{
    public required FolderScanState State { get; init; }
    public required IReadOnlyList<BlobScanInfo> Blobs { get; init; }
}
