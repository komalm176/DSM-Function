using Azure.Storage.Blobs;
using Azure.Storage.Files.DataLake;
using EmailScanProcessor.Models;
using EmailScanProcessor.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

var builder = FunctionsApplication.CreateBuilder(args);

// Application Insights
builder.Services
    .AddApplicationInsightsTelemetryWorkerService()
    .ConfigureFunctionsApplicationInsights();

// Options
builder.Services
    .AddOptions<ScanProcessorOptions>()
    .Bind(builder.Configuration.GetSection(ScanProcessorOptions.SectionName))
    .ValidateDataAnnotations();

// Blob + Data Lake clients (same account; one connection string)
var blobConn = builder.Configuration["BlobStorageConnectionString"]
    ?? throw new InvalidOperationException("BlobStorageConnectionString is missing.");

builder.Services.AddSingleton(_ => new BlobServiceClient(blobConn));
builder.Services.AddSingleton(_ => new DataLakeServiceClient(blobConn));

// SQL repository
var sqlConn = builder.Configuration["SqlConnectionString"]
    ?? throw new InvalidOperationException("SqlConnectionString is missing.");

builder.Services.AddSingleton<IEmailDocumentRepository>(sp =>
    new EmailDocumentRepository(sqlConn, sp.GetRequiredService<ILogger<EmailDocumentRepository>>()));

builder.Services.AddSingleton<IBlobScanService, BlobScanService>();

await builder.Build().RunAsync();
