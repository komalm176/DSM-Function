using EmailScanProcessor.Models;

namespace EmailScanProcessor.Services;

public interface IBlobProcessorService
{
    /// <summary>
    /// All blobs in the folder were tagged clean by Defender. For each blob:
    /// - download
    /// - if zip: extract each entry, convert each to PDF, upload
    /// - otherwise: convert to PDF, upload
    /// - delete source on success
    /// On any per-file failure, rolls back uploaded files in the destination
    /// and returns false (caller leaves the SQL row as ScanPending).
    /// </summary>
    Task<bool> ProcessCleanFolderAsync(
        IReadOnlyList<BlobScanInfo> blobs,
        string folderName,
        CancellationToken ct);

    /// <summary>
    /// At least one blob in the folder was flagged Malicious. Moves the entire
    /// folder (all blobs as-is, no conversion) to the quarantine container.
    /// </summary>
    Task<bool> QuarantineFolderAsync(
        IReadOnlyList<BlobScanInfo> blobs,
        string folderName,
        CancellationToken ct);
}
