namespace EmailScanProcessor.Services;

public interface IPdfConverter
{
    /// <summary>
    /// Converts raw file bytes to PDF.
    /// - .pdf input → repaired/re-serialized via iText 7.
    /// - anything else → treated as an image and drawn onto a PDF page via Syncfusion.
    /// </summary>
    byte[] ConvertToPdf(byte[] fileContent, string fileName);
}
