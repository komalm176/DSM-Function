using EmailUpload.Functions.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Azure.Storage.Blobs;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((context, services) =>
    {
        // ── Application Insights ──────────────────────────────────────────
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        // ── Azure Blob Storage ────────────────────────────────────────────
        services.AddSingleton(new BlobServiceClient(
            Environment.GetEnvironmentVariable("AzureWebJobsStorage")!));

        // ── Services ──────────────────────────────────────────────────────
        services.AddScoped<BlobService>();
        services.AddScoped<SqlService>();

        // ── Logging ───────────────────────────────────────────────────────
        services.AddLogging();
    })
    .Build();

await host.RunAsync();
