using EmailScanProcessor.Models;

namespace EmailScanProcessor.Services;

public interface IEmailDocumentRepository
{
    Task<IReadOnlyList<EmailDocument>> GetPendingDocumentsAsync(
        int batchSize,
        int ageThresholdHours,
        CancellationToken ct);

    /// <summary>
    /// Updates the row identified by id with a new status and the new attachment path
    /// (folder name in destination/quarantine container). Only succeeds if the row is
    /// still in ScanPending status (optimistic guard against double-processing).
    /// </summary>
    Task<bool> UpdateAfterProcessingAsync(
        long id,
        string newStatus,
        string newAttachmentPath,
        CancellationToken ct);
}
