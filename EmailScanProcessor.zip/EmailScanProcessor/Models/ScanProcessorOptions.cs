namespace EmailScanProcessor.Models;

public sealed class ScanProcessorOptions
{
    public const string SectionName = "ScanProcessor";

    public string ScheduleCron { get; set; } = "0 */5 * * * *";
    public string SourceContainer { get; set; } = "email-scanpending";
    public string DestinationContainer { get; set; } = "email-processed";
    public string QuarantineContainer { get; set; } = "email-quarantine";
    public int BatchSize { get; set; } = 100;
    public int AgeThresholdHours { get; set; } = 4;

    /// <summary>
    /// Optional Syncfusion license key. If empty, Syncfusion will operate in trial mode
    /// (adds a watermark to generated PDFs).
    /// </summary>
    public string SyncfusionLicenseKey { get; set; } = string.Empty;
}
