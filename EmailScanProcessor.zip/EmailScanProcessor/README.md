# EmailScanProcessor

Timer-triggered Azure Function (.NET 10, isolated worker) that:

1. Polls `dbo.EmailDocuments` for rows where `EmailStatus = 'ScanPending'` and `CreatedOn < now - 4h`.
2. Pulls up to 100 rows per cycle (configurable).
3. For each row, lists every blob under `email-scanpending/<EmailAttachmentPath>/` and reads the Defender for Storage scan-result blob index tag.
4. Branches based on the folder's overall scan state:

| Scan result | Action on each file | SQL update |
|---|---|---|
| All blobs clean (`No threats found`) | Extract ZIPs in place, convert every file to PDF via iText 7 (for PDFs) or Syncfusion (for images), upload to `email-processed/<folder>/`, delete source | `EmailStatus = 'Ready for Review'`, `EmailAttachmentPath = '<folder>'` |
| Any blob `Malicious` | Move every file as-is (no conversion) to `email-quarantine/<folder>/`, delete source | `EmailStatus = 'Malicious'`, `EmailAttachmentPath = '<folder>'` |
| Any blob with no scan tag yet | Skip — leaves row as `ScanPending`, retries next cycle | None |
| Folder empty | Skip — logs a warning | None |

If any per-file failure happens inside the clean or quarantine path, all already-uploaded destination files are rolled back (deleted) and the source row is left as `ScanPending` for retry. SQL is updated only when the entire folder succeeds.

---

## Required Azure prerequisites

- **Defender for Storage on `sftpdatalakedev01`** with "Store scan results as blob index tags" checked. (Already done.)
- **Microsoft.Storage/BlobIndexForHns AFEC preview** registered on the subscription. (Already done.)
- **Containers exist:** `email-scanpending` (source), `email-processed` (destination), `email-quarantine` (malicious sink). The function will `CreateIfNotExists` on the destination and quarantine on first use, but creating them manually is cleaner.

---

## PDF conversion details

The `PdfConverter` matches the existing CAQH `ConvertToPdf` pattern but uses modern libraries:

- **`.pdf` input** → iText 7 (`itext7` 8.0.5). Repairs and re-serialises via `PdfReader` → `PdfDocument.CopyPagesTo` (the iText 7 equivalent of the legacy iTextSharp `PdfCopy.AddPage` loop).
- **Non-PDF input** → Syncfusion (`Syncfusion.Pdf.Net.Core` 27.x). Assumes the bytes are decodable by `PdfBitmap` (PNG, JPG, GIF, BMP, TIFF). Anything else will throw, which is correctly treated as a per-file failure.

### Licensing

- **iText 7** is AGPL or commercial. Required only if you're distributing AGPL software or you hold an iText commercial license. The code does not require a license key at runtime.
- **Syncfusion** is commercial. Without a license key, generated PDFs carry a trial watermark. Set `ScanProcessor:SyncfusionLicenseKey` in app settings to suppress this.

---

## Local dev

```bash
dotnet --list-sdks                 # need 10.x
func --version                     # Azure Functions Core Tools v4

cd EmailScanProcessor
dotnet restore
func start
```

Fill in `local.settings.json` with real `SqlConnectionString`, `BlobStorageConnectionString`, and optionally `ScanProcessor:SyncfusionLicenseKey` before running.

---

## Configuration keys

| Key | Purpose | Default |
|---|---|---|
| `SqlConnectionString` | SQL Server connection | — |
| `BlobStorageConnectionString` | Storage account connection string | — |
| `ScanProcessor:ScheduleCron` | NCRONTAB schedule | `0 */5 * * * *` (every 5 min) |
| `ScanProcessor:SourceContainer` | Where `ScanPending` folders live | `email-scanpending` |
| `ScanProcessor:DestinationContainer` | Where clean folders go | `email-processed` |
| `ScanProcessor:QuarantineContainer` | Where malicious folders go | `email-quarantine` |
| `ScanProcessor:BatchSize` | Rows per cycle | `100` |
| `ScanProcessor:AgeThresholdHours` | Only pick rows older than this | `4` |
| `ScanProcessor:SyncfusionLicenseKey` | Syncfusion license key (optional) | `""` |

---

## End-to-end test

1. Pick a row in `dbo.EmailDocuments` whose `CreatedOn` is already older than 4 h.
2. Upload a fresh attachment to `email-scanpending/<folder>/file.pdf` (and/or a `.png`, `.jpg`, `.zip` containing PDFs/images).
3. Wait ~1-2 min for Defender to scan and write tags.
4. Update the SQL row:
   ```sql
   UPDATE dbo.EmailDocuments
      SET EmailStatus = 'ScanPending',
          EmailAttachmentPath = '<folder>'
    WHERE Id = <n>;
   ```
5. `func start`. On the next tick you should see:
   ```
   Fetched 1 ScanPending document(s) older than 4h
   Id=<n> folder=<folder>: processed and marked 'Ready for Review'.
   ```
6. Verify: source folder is gone, `email-processed/<folder>/*.pdf` exists, SQL row has `EmailStatus = 'Ready for Review'`.

For the malicious path, use the EICAR test file (standard antivirus test sample). Defender will flag it; after the next cycle the folder should land in `email-quarantine` and the row should read `Malicious`.

---

## Project layout

```
Program.cs                          — FunctionsApplication builder + DI
Functions/EmailScanProcessor.cs     — timer trigger orchestration
Services/IBlobScanService.cs        — interface
Services/BlobScanService.cs         — reads Defender index tags, classifies folder
Services/IBlobProcessorService.cs   — interface
Services/BlobProcessorService.cs    — extract zips, convert to PDF, move, rollback,
                                       quarantine
Services/IPdfConverter.cs           — interface
Services/PdfConverter.cs            — iText 7 + Syncfusion
Services/IEmailDocumentRepository.cs— interface
Services/EmailDocumentRepository.cs — Dapper SQL access
Models/EmailDocument.cs             — table row
Models/EmailStatuses.cs             — status string constants
Models/BlobScanInfo.cs              — blob + scan result wrapper
Models/FolderScanResult.cs          — folder classification + per-blob info
Models/ScanProcessorOptions.cs      — strongly-typed config
```

---

## Things deliberately deferred

- **Concurrency lock.** Two function instances could grab the same rows; add a `Processing` intermediate state if you ever scale out beyond one instance.
- **Managed identity.** Using connection strings as specified; swap to `DefaultAzureCredential` later.
- **Non-PDF/non-image file types.** Only PDF + raster images are supported (per scenario A). Office docs, .msg/.eml, HTML, etc., will fail conversion and trigger a rollback. Add file-type-specific handlers if those become in-scope.
