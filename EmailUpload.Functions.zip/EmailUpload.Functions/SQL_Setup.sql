-- ─────────────────────────────────────────────────────────────────────────────
-- Email Processor — SQL Setup Script
-- Run this script once against your database before deploying the Function App
-- ─────────────────────────────────────────────────────────────────────────────

-- ── Create EmailDocument table ────────────────────────────────────────────────
IF NOT EXISTS (
    SELECT 1 FROM INFORMATION_SCHEMA.TABLES
    WHERE TABLE_NAME = 'EmailDocument'
)
BEGIN
    CREATE TABLE EmailDocument (

        -- Primary key
        Id                  INT             IDENTITY(1,1)   NOT NULL,

        -- Email metadata (from Logic App / Service Bus payload)
        MessageId           NVARCHAR(255)   NOT NULL,
        SenderAddress       NVARCHAR(255)   NULL,
        EmailSubject        NVARCHAR(998)   NULL,
        EmailBody           NVARCHAR(MAX)   NULL,

        -- Blob storage path (updated by Function App to destination folder)
        EmailAttachmentPath NVARCHAR(2048)  NULL,

        -- Processing status (set by Function App)
        -- Possible values: ReadyForUpload, Malicious, ScanPending,
        --                  MissingAttachment, MoveFailed
        EmailStatus         NVARCHAR(50)    NOT NULL,
        EmailStatusReason   NVARCHAR(1024)  NULL,

        -- Timestamps
        SendDateTime        DATETIME2       NOT NULL,
        CreatedDateTime     DATETIME2       NOT NULL,

        -- Constraints
        CONSTRAINT PK_EmailDocument
            PRIMARY KEY CLUSTERED (Id ASC),

        CONSTRAINT UQ_EmailDocument_MessageId
            UNIQUE NONCLUSTERED (MessageId)
    );

    PRINT 'EmailDocument table created successfully.';
END
ELSE
BEGIN
    PRINT 'EmailDocument table already exists. Skipping creation.';
END
GO

-- ── Indexes ───────────────────────────────────────────────────────────────────

-- Index for fast idempotency check (MessageId lookup on every message)
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_EmailDocument_MessageId'
    AND object_id = OBJECT_ID('EmailDocument')
)
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX IX_EmailDocument_MessageId
        ON EmailDocument (MessageId ASC);

    PRINT 'Index IX_EmailDocument_MessageId created successfully.';
END
GO

-- Index for status-based queries (monitoring / dashboard)
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_EmailDocument_EmailStatus'
    AND object_id = OBJECT_ID('EmailDocument')
)
BEGIN
    CREATE NONCLUSTERED INDEX IX_EmailDocument_EmailStatus
        ON EmailDocument (EmailStatus ASC)
        INCLUDE (MessageId, SenderAddress, EmailSubject, CreatedDateTime);

    PRINT 'Index IX_EmailDocument_EmailStatus created successfully.';
END
GO

-- Index for date range queries (reporting / audit)
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_EmailDocument_CreatedDateTime'
    AND object_id = OBJECT_ID('EmailDocument')
)
BEGIN
    CREATE NONCLUSTERED INDEX IX_EmailDocument_CreatedDateTime
        ON EmailDocument (CreatedDateTime DESC)
        INCLUDE (MessageId, EmailStatus, SenderAddress);

    PRINT 'Index IX_EmailDocument_CreatedDateTime created successfully.';
END
GO

-- ── Verify setup ──────────────────────────────────────────────────────────────
PRINT '─────────────────────────────────────────';
PRINT 'Setup complete. Verifying...';
PRINT '─────────────────────────────────────────';

-- Show table columns
SELECT
    COLUMN_NAME         AS [Column],
    DATA_TYPE           AS [Type],
    IS_NULLABLE         AS [Nullable],
    CHARACTER_MAXIMUM_LENGTH AS [MaxLength]
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'EmailDocument'
ORDER BY ORDINAL_POSITION;

-- Show indexes
SELECT
    i.name              AS [Index],
    i.type_desc         AS [Type],
    i.is_unique         AS [Unique]
FROM sys.indexes i
WHERE i.object_id = OBJECT_ID('EmailDocument')
AND i.name IS NOT NULL
ORDER BY i.name;

PRINT '─────────────────────────────────────────';
PRINT 'SQL setup completed successfully.';
PRINT '─────────────────────────────────────────';
GO

-- ── Useful queries for testing / monitoring ───────────────────────────────────

-- View all records (most recent first)
-- SELECT * FROM EmailDocument ORDER BY CreatedDateTime DESC;

-- Check by status
-- SELECT * FROM EmailDocument WHERE EmailStatus = 'ReadyForUpload' ORDER BY CreatedDateTime DESC;
-- SELECT * FROM EmailDocument WHERE EmailStatus = 'Malicious'      ORDER BY CreatedDateTime DESC;
-- SELECT * FROM EmailDocument WHERE EmailStatus = 'ScanPending'    ORDER BY CreatedDateTime DESC;
-- SELECT * FROM EmailDocument WHERE EmailStatus = 'MissingAttachment' ORDER BY CreatedDateTime DESC;
-- SELECT * FROM EmailDocument WHERE EmailStatus = 'MoveFailed'     ORDER BY CreatedDateTime DESC;

-- Check specific MessageId
-- SELECT * FROM EmailDocument WHERE MessageId = 'YOUR-MESSAGE-ID';

-- Count by status (dashboard)
-- SELECT EmailStatus, COUNT(*) AS Count FROM EmailDocument GROUP BY EmailStatus ORDER BY Count DESC;

-- Records in last 24 hours
-- SELECT * FROM EmailDocument WHERE CreatedDateTime >= DATEADD(HOUR, -24, GETUTCDATE()) ORDER BY CreatedDateTime DESC;
