using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Azure.Storage.Files.DataLake;
using EmailScanProcessor.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EmailScanProcessor.Services;

public sealed class BlobScanService : IBlobScanService
{
    // Tag key Defender for Storage writes when "Store scan results as blob index tags" is enabled.
    // Documented values: "No threats found" | "Malicious".
    private const string ScanResultTagKey = "Malware Scanning scan result";
    private const string ScanResultClean = "No threats found";
    private const string ScanResultMalicious = "Malicious";

    private readonly BlobServiceClient _blobService;
    private readonly DataLakeServiceClient _dataLakeService;
    private readonly ScanProcessorOptions _options;
    private readonly ILogger<BlobScanService> _logger;

    public BlobScanService(
        BlobServiceClient blobService,
        DataLakeServiceClient dataLakeService,
        IOptions<ScanProcessorOptions> options,
        ILogger<BlobScanService> logger)
    {
        _blobService = blobService;
        _dataLakeService = dataLakeService;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<FolderScanState> EvaluateFolderAsync(
        string sourceContainer,
        string folderName,
        CancellationToken ct)
    {
        var prefix = NormalizePrefix(folderName);
        var container = _blobService.GetBlobContainerClient(sourceContainer);

        var blobCount = 0;
        await foreach (BlobItem blob in container.GetBlobsAsync(prefix: prefix, cancellationToken: ct))
        {
            blobCount++;
            var blobClient = container.GetBlobClient(blob.Name);

            GetBlobTagResult tagResult;
            try
            {
                tagResult = await blobClient.GetTagsAsync(cancellationToken: ct);
            }
            catch (RequestFailedException ex)
            {
                _logger.LogWarning(ex,
                    "Failed to read tags for {Blob}. Treating folder {Folder} as not-yet-scanned.",
                    blob.Name, folderName);
                return FolderScanState.AnyUnscanned;
            }

            if (!tagResult.Tags.TryGetValue(ScanResultTagKey, out var result))
            {
                _logger.LogInformation("Blob {Blob} has no scan-result tag yet. Will retry next run.", blob.Name);
                return FolderScanState.AnyUnscanned;
            }

            if (string.Equals(result, ScanResultMalicious, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("Blob {Blob} flagged as Malicious. Skipping folder {Folder}.", blob.Name, folderName);
                return FolderScanState.AnyMalicious;
            }

            if (!string.Equals(result, ScanResultClean, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning("Blob {Blob} has unexpected scan-result value '{Value}'. Treating as unscanned.",
                    blob.Name, result);
                return FolderScanState.AnyUnscanned;
            }
        }

        if (blobCount == 0)
        {
            _logger.LogWarning("Folder {Folder} in container {Container} is empty.", folderName, sourceContainer);
            return FolderScanState.Empty;
        }

        return FolderScanState.AllClean;
    }

    public async Task MoveFolderAsync(
        string sourceContainer,
        string destinationContainer,
        string folderName,
        CancellationToken ct)
    {
        if (_options.UseAdlsRename)
        {
            await MoveFolderViaAdlsRenameAsync(sourceContainer, destinationContainer, folderName, ct);
        }
        else
        {
            await MoveFolderViaCopyDeleteAsync(sourceContainer, destinationContainer, folderName, ct);
        }
    }

    // Preferred path for HNS-enabled (ADLS Gen2) accounts: server-side metadata rename.
    // RenameAsync supports cross-filesystem rename within the same storage account.
    private async Task MoveFolderViaAdlsRenameAsync(
        string sourceContainer,
        string destinationContainer,
        string folderName,
        CancellationToken ct)
    {
        var srcFs = _dataLakeService.GetFileSystemClient(sourceContainer);
        var destFs = _dataLakeService.GetFileSystemClient(destinationContainer);
        await destFs.CreateIfNotExistsAsync(cancellationToken: ct);

        var srcDir = srcFs.GetDirectoryClient(folderName);

        if (!await srcDir.ExistsAsync(ct))
        {
            _logger.LogWarning("Source directory {Folder} not found in {Container}; nothing to move.",
                folderName, sourceContainer);
            return;
        }

        // destinationPath is "{filesystem}/{path}" to rename across filesystems.
        var destinationPath = $"{destinationContainer}/{folderName}";
        await srcDir.RenameAsync(destinationPath, cancellationToken: ct);

        _logger.LogInformation("Renamed {Folder} from {Src} to {Dst} (ADLS metadata move).",
            folderName, sourceContainer, destinationContainer);
    }

    // Fallback path: server-side copy + delete each blob.
    private async Task MoveFolderViaCopyDeleteAsync(
        string sourceContainer,
        string destinationContainer,
        string folderName,
        CancellationToken ct)
    {
        var prefix = NormalizePrefix(folderName);
        var src = _blobService.GetBlobContainerClient(sourceContainer);
        var dst = _blobService.GetBlobContainerClient(destinationContainer);
        await dst.CreateIfNotExistsAsync(cancellationToken: ct);

        await foreach (BlobItem blob in src.GetBlobsAsync(prefix: prefix, cancellationToken: ct))
        {
            var srcBlob = src.GetBlobClient(blob.Name);
            var dstBlob = dst.GetBlobClient(blob.Name);

            await dstBlob.SyncCopyFromUriAsync(srcBlob.Uri, cancellationToken: ct);
            await srcBlob.DeleteIfExistsAsync(cancellationToken: ct);

            _logger.LogDebug("Moved {Blob} from {Src} to {Dst}", blob.Name, sourceContainer, destinationContainer);
        }

        _logger.LogInformation("Copy+delete move complete for folder {Folder}.", folderName);
    }

    private static string NormalizePrefix(string folderName)
    {
        var trimmed = folderName.Trim().Trim('/');
        return trimmed.EndsWith('/') ? trimmed : trimmed + "/";
    }
}
