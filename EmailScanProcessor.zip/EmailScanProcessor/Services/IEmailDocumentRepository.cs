using EmailScanProcessor.Models;

namespace EmailScanProcessor.Services;

public interface IEmailDocumentRepository
{
    Task<IReadOnlyList<EmailDocument>> GetPendingDocumentsAsync(
        int batchSize,
        int ageThresholdHours,
        CancellationToken ct);

    Task MarkReadyForUploadAsync(long id, CancellationToken ct);
}
