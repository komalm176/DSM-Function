using EmailScanProcessor.Models;

namespace EmailScanProcessor.Services;

public interface IBlobScanService
{
    /// <summary>
    /// Lists every blob under sourceContainer/<folderName>/ and inspects the
    /// Defender for Storage "Malware Scanning scan result" blob index tag on each.
    /// Returns a classification for the whole folder plus the per-blob info.
    /// </summary>
    Task<FolderScanResult> EvaluateFolderAsync(
        string sourceContainer,
        string folderName,
        CancellationToken ct);
}
