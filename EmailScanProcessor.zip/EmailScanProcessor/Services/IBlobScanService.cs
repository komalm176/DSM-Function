namespace EmailScanProcessor.Services;

public enum FolderScanState
{
    AllClean,
    AnyMalicious,
    AnyUnscanned,
    Empty
}

public interface IBlobScanService
{
    Task<FolderScanState> EvaluateFolderAsync(
        string sourceContainer,
        string folderName,
        CancellationToken ct);

    Task MoveFolderAsync(
        string sourceContainer,
        string destinationContainer,
        string folderName,
        CancellationToken ct);
}
