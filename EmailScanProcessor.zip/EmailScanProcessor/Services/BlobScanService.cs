using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using EmailScanProcessor.Models;
using Microsoft.Extensions.Logging;

namespace EmailScanProcessor.Services;

public sealed class BlobScanService : IBlobScanService
{
    // Tag key Defender for Storage writes when "Store scan results as blob index tags" is enabled.
    private const string ScanResultTagKey = "Malware Scanning scan result";
    private const string ScanResultClean = "No threats found";
    private const string ScanResultMalicious = "Malicious";

    private readonly BlobServiceClient _blobService;
    private readonly ILogger<BlobScanService> _logger;

    public BlobScanService(BlobServiceClient blobService, ILogger<BlobScanService> logger)
    {
        _blobService = blobService;
        _logger = logger;
    }

    public async Task<FolderScanResult> EvaluateFolderAsync(
        string sourceContainer,
        string folderName,
        CancellationToken ct)
    {
        var prefix = NormalizePrefix(folderName);
        var container = _blobService.GetBlobContainerClient(sourceContainer);

        var blobs = new List<BlobScanInfo>();
        var hasMalicious = false;
        var hasUnscanned = false;

        await foreach (BlobItem item in container.GetBlobsAsync(prefix: prefix, cancellationToken: ct))
        {
            var client = container.GetBlobClient(item.Name);
            string? result = null;

            try
            {
                var tagResult = await client.GetTagsAsync(cancellationToken: ct);
                tagResult.Value.Tags.TryGetValue(ScanResultTagKey, out result);
            }
            catch (RequestFailedException ex)
            {
                _logger.LogWarning(ex,
                    "Failed to read tags for {Blob}. Treating folder {Folder} as not-yet-scanned.",
                    item.Name, folderName);
                hasUnscanned = true;
            }

            blobs.Add(new BlobScanInfo { Item = item, Client = client, ScanResult = result });

            if (string.IsNullOrEmpty(result))
            {
                hasUnscanned = true;
            }
            else if (string.Equals(result, ScanResultMalicious, StringComparison.OrdinalIgnoreCase))
            {
                hasMalicious = true;
            }
            else if (!string.Equals(result, ScanResultClean, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogWarning(
                    "Blob {Blob} has unexpected scan-result value '{Value}'. Treating as unscanned.",
                    item.Name, result);
                hasUnscanned = true;
            }
        }

        FolderScanState state;
        if (blobs.Count == 0) state = FolderScanState.Empty;
        else if (hasMalicious) state = FolderScanState.AnyMalicious;
        else if (hasUnscanned) state = FolderScanState.AnyUnscanned;
        else state = FolderScanState.AllClean;

        return new FolderScanResult { State = state, Blobs = blobs };
    }

    private static string NormalizePrefix(string folderName)
    {
        var trimmed = folderName.Trim().Trim('/');
        return trimmed.EndsWith('/') ? trimmed : trimmed + "/";
    }
}
