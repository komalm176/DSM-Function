namespace EmailScanProcessor.Models;

/// <summary>
/// String constants for the EmailStatus column. Kept as strings to match the existing schema.
/// </summary>
public static class EmailStatuses
{
    public const string ScanPending = "ScanPending";
    public const string ReadyForReview = "Ready for Review";
    public const string Malicious = "Malicious";
}
