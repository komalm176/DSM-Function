namespace EmailUpload.Functions.Models
{
    /// <summary>
    /// Constants representing all possible email processing statuses.
    /// </summary>
    public static class EmailStatus
    {
        public const string ReadyForUpload    = "ReadyForUpload";    // All attachments clean, moved to processed
        public const string Malicious         = "Malicious";         // At least one attachment malicious
        public const string ScanPending       = "ScanPending";       // Scan incomplete after max retries
        public const string MissingAttachment = "MissingAttachment"; // No attachment path or empty folder
        public const string MoveFailed        = "MoveFailed";        // Blob move failed after retries, rolled back
    }
}
