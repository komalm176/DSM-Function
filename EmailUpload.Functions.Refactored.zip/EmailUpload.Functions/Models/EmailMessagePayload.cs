using System;

namespace EmailUpload.Functions.Models
{
    /// <summary>
    /// Represents the Service Bus message payload sent by the Logic App.
    /// </summary>
    public class EmailMessagePayload
    {
        /// <summary>Unique identifier from the email's Message-ID header.</summary>
        public string MessageId { get; set; } = string.Empty;

        /// <summary>Sender's email address (extracted from From header).</summary>
        public string? SenderAddress { get; set; }

        /// <summary>Subject line of the email.</summary>
        public string? EmailSubject { get; set; }

        /// <summary>Plain-text or HTML body of the email.</summary>
        public string? EmailBody { get; set; }

        /// <summary>
        /// Blob storage folder path containing all attachments.
        /// Format: "email-staging/{sanitisedMessageId}_{sendDateTimeUtc}/"
        /// Null when no attachment is present.
        /// Updated by this function to reflect the destination folder after processing.
        /// </summary>
        public string? EmailAttachmentPath { get; set; }

        /// <summary>Processing status — set by this function using <see cref="EmailStatus"/> constants.</summary>
        public string? EmailStatus { get; set; }

        /// <summary>Human-readable reason for the current status (failure / rejection reason).</summary>
        public string? EmailStatusReason { get; set; }

        /// <summary>UTC date/time the email was originally sent by the sender.</summary>
        public DateTime SendDateTime { get; set; }

        /// <summary>UTC date/time this record was created — stamped by this function.</summary>
        public DateTime CreatedDateTime { get; set; }
    }
}
