using System;
using System.Threading.Tasks;
using EmailUpload.Functions.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace EmailUpload.Functions.Services
{
    /// <summary>
    /// Handles all SQL database operations for the email processor.
    /// </summary>
    public class SqlService
    {
        private readonly ILogger<SqlService> _logger;
        private readonly string              _connectionString;
        private readonly int                 _maxRetries;

        public SqlService(ILogger<SqlService> logger)
        {
            _logger           = logger;
            _connectionString = Environment.GetEnvironmentVariable("SqlConnectionString")!;
            _maxRetries       = int.TryParse(Environment.GetEnvironmentVariable("MaxMoveRetries"), out int m) ? m : 3;
        }

        // ─────────────────────────────────────────────────────────────────────
        // Idempotency check
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Returns true if a row with the given MessageId already exists in EmailDocument.
        /// Used for idempotency — prevents duplicate processing on message redelivery.
        /// </summary>
        public async Task<bool> MessageIdExistsAsync(string messageId)
        {
            const string sql = "SELECT COUNT(1) FROM EmailDocument WHERE MessageId = @MessageId";

            await using var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();
            await using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@MessageId", messageId);

            return (int)(await cmd.ExecuteScalarAsync())! > 0;
        }

        // ─────────────────────────────────────────────────────────────────────
        // Insert
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Inserts a new EmailDocument row with retry (up to MaxMoveRetries).
        /// Returns true on success, false if all retries failed.
        /// </summary>
        public async Task<bool> InsertEmailDocumentAsync(
            EmailMessagePayload payload,
            string              status,
            string?             statusReason = null)
        {
            const string sql = @"
                INSERT INTO EmailDocument
                    (MessageId, SenderAddress, EmailSubject, EmailBody,
                     EmailAttachmentPath, EmailStatus, EmailStatusReason,
                     SendDateTime, CreatedDateTime)
                VALUES
                    (@MessageId, @SenderAddress, @EmailSubject, @EmailBody,
                     @EmailAttachmentPath, @EmailStatus, @EmailStatusReason,
                     @SendDateTime, @CreatedDateTime)";

            for (int attempt = 1; attempt <= _maxRetries; attempt++)
            {
                try
                {
                    await using var conn = new SqlConnection(_connectionString);
                    await conn.OpenAsync();
                    await using var cmd = new SqlCommand(sql, conn);

                    cmd.Parameters.AddWithValue("@MessageId",           payload.MessageId);
                    cmd.Parameters.AddWithValue("@SenderAddress",       (object?)payload.SenderAddress       ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@EmailSubject",        (object?)payload.EmailSubject        ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@EmailBody",           (object?)payload.EmailBody           ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@EmailAttachmentPath", (object?)payload.EmailAttachmentPath ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@EmailStatus",         status);
                    cmd.Parameters.AddWithValue("@EmailStatusReason",   (object?)statusReason                ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@SendDateTime",        payload.SendDateTime);
                    cmd.Parameters.AddWithValue("@CreatedDateTime",     payload.CreatedDateTime);

                    await cmd.ExecuteNonQueryAsync();

                    _logger.LogInformation(
                        "EmailDocument inserted — MessageId={Id}, Status={Status}",
                        payload.MessageId, status);

                    return true;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex,
                        "SQL insert attempt {Attempt}/{Max} failed for MessageId={Id}.",
                        attempt, _maxRetries, payload.MessageId);

                    if (attempt < _maxRetries)
                        await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, attempt)));
                }
            }

            _logger.LogCritical(
                "SQL insert failed after {Max} retries for MessageId={Id}.",
                _maxRetries, payload.MessageId);

            return false;
        }
    }
}
