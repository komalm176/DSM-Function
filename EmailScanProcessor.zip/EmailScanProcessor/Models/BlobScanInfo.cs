using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace EmailScanProcessor.Models;

/// <summary>
/// One blob with its Defender scan result (read from blob index tags).
/// </summary>
public sealed class BlobScanInfo
{
    public required BlobItem Item { get; init; }
    public required BlobClient Client { get; init; }
    public string? ScanResult { get; init; }
}
