using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Azure;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((context, services) =>
    {
        // ── Application Insights ──────────────────────────────────────────
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        // ── Azure Blob Storage ────────────────────────────────────────────
        services.AddAzureClients(clientBuilder =>
        {
            clientBuilder.AddBlobServiceClient(
                Environment.GetEnvironmentVariable("AzureWebJobsStorage")!);
        });

        // ── Logging ───────────────────────────────────────────────────────
        services.AddLogging();
    })
    .Build();

await host.RunAsync();
