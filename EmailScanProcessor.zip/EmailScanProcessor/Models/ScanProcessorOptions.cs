namespace EmailScanProcessor.Models;

public sealed class ScanProcessorOptions
{
    public const string SectionName = "ScanProcessor";

    public string ScheduleCron { get; set; } = "0 */5 * * * *";
    public string SourceContainer { get; set; } = "email-scanpending";
    public string DestinationContainer { get; set; } = "email-processed";
    public int BatchSize { get; set; } = 100;
    public int AgeThresholdHours { get; set; } = 4;

    /// <summary>
    /// If true (recommended for HNS / ADLS Gen2 accounts), use server-side
    /// DataLakeFileClient.RenameAsync to move blobs between containers.
    /// If false, fall back to copy + delete.
    /// </summary>
    public bool UseAdlsRename { get; set; } = true;
}
