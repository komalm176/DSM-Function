using Microsoft.Azure.Functions.Worker;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace AutoReleaseLocks;

public class AutoReleaseLocksFunction
{
    private readonly ILogger<AutoReleaseLocksFunction> _logger;

    public AutoReleaseLocksFunction(ILogger<AutoReleaseLocksFunction> logger)
    {
        _logger = logger;
    }

    // Runs every 4 hours. CRON is {second} {minute} {hour} {day} {month} {day-of-week}.
    // "0 0 */4 * * *" => at minute 0 of every 4th hour (00:00, 04:00, 08:00, ...).
    [Function("AutoReleaseLocks")]
    public async Task Run([TimerTrigger("0 0 */4 * * *")] TimerInfo timer)
    {
        _logger.LogInformation("AutoReleaseLocks started at {time} (UTC).", DateTime.UtcNow);

        var connectionString = Environment.GetEnvironmentVariable("SqlConnectionString");
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            _logger.LogError("SqlConnectionString is not configured. Aborting.");
            return;
        }

        // Lock age threshold in hours; configurable per the ticket. Defaults to 24.
        var lockHours = 24;
        var configuredHours = Environment.GetEnvironmentVariable("LockReleaseHours");
        if (!string.IsNullOrWhiteSpace(configuredHours) && int.TryParse(configuredHours, out var parsed) && parsed > 0)
        {
            lockHours = parsed;
        }

        const string sql = @"
UPDATE dbo.EmailDocuments
SET    EmailStatus       = @ToStatus,
       EmailStatusReason = @Reason,
       ModifiedOn        = SYSUTCDATETIME(),
       ModifiedBy        = @ModifiedBy
WHERE  EmailStatus = @FromStatus
  AND  ModifiedOn IS NOT NULL
  AND  ModifiedOn <= DATEADD(HOUR, -@LockHours, SYSUTCDATETIME());";

        try
        {
            await using var conn = new SqlConnection(connectionString);
            await conn.OpenAsync();

            await using var cmd = new SqlCommand(sql, conn);
            cmd.CommandTimeout = 60;
            cmd.Parameters.AddWithValue("@FromStatus", "In Review");
            cmd.Parameters.AddWithValue("@ToStatus", "Ready for Review");
            cmd.Parameters.AddWithValue("@Reason", "Lock auto-released after timeout.");
            cmd.Parameters.AddWithValue("@ModifiedBy", "AutoReleaseLocksFunction");
            cmd.Parameters.AddWithValue("@LockHours", lockHours);

            var affected = await cmd.ExecuteNonQueryAsync();
            _logger.LogInformation(
                "AutoReleaseLocks completed. {count} document(s) older than {hours}h moved from 'In Review' to 'Ready for Review'.",
                affected, lockHours);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "AutoReleaseLocks failed while updating EmailDocuments.");
            throw; // surface failure so the invocation is marked failed and retried/alerted
        }
    }
}
