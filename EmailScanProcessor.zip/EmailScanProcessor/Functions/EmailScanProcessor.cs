using EmailScanProcessor.Models;
using EmailScanProcessor.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EmailScanProcessor.Functions;

public sealed class EmailScanProcessor
{
    private readonly IEmailDocumentRepository _repo;
    private readonly IBlobScanService _blobs;
    private readonly ScanProcessorOptions _options;
    private readonly ILogger<EmailScanProcessor> _logger;

    public EmailScanProcessor(
        IEmailDocumentRepository repo,
        IBlobScanService blobs,
        IOptions<ScanProcessorOptions> options,
        ILogger<EmailScanProcessor> logger)
    {
        _repo = repo;
        _blobs = blobs;
        _options = options.Value;
        _logger = logger;
    }

    [Function(nameof(EmailScanProcessor))]
    public async Task RunAsync(
        [TimerTrigger("%ScanProcessor:ScheduleCron%")] TimerInfo timer,
        CancellationToken ct)
    {
        _logger.LogInformation("EmailScanProcessor starting. Next: {Next}", timer.ScheduleStatus?.Next);

        var pending = await _repo.GetPendingDocumentsAsync(_options.BatchSize, _options.AgeThresholdHours, ct);
        if (pending.Count == 0)
        {
            _logger.LogInformation("No pending documents this cycle.");
            return;
        }

        var clean = 0;
        var malicious = 0;
        var unscanned = 0;
        var empty = 0;
        var failed = 0;

        foreach (var doc in pending)
        {
            ct.ThrowIfCancellationRequested();

            var folder = ExtractFolderName(doc.EmailAttachmentPath);
            if (string.IsNullOrWhiteSpace(folder))
            {
                _logger.LogWarning("Id={Id}: EmailAttachmentPath '{Path}' could not be parsed.", doc.Id, doc.EmailAttachmentPath);
                failed++;
                continue;
            }

            try
            {
                var state = await _blobs.EvaluateFolderAsync(_options.SourceContainer, folder, ct);

                switch (state)
                {
                    case FolderScanState.AllClean:
                        await _blobs.MoveFolderAsync(_options.SourceContainer, _options.DestinationContainer, folder, ct);
                        await _repo.MarkReadyForUploadAsync(doc.Id, ct);
                        clean++;
                        _logger.LogInformation("Id={Id} folder={Folder}: moved and marked ReadyForUpload.", doc.Id, folder);
                        break;

                    case FolderScanState.AnyMalicious:
                        malicious++;
                        // Per spec: skip the row. Status stays ScanPending; revisit later if a Quarantined status is added.
                        break;

                    case FolderScanState.AnyUnscanned:
                        unscanned++;
                        break;

                    case FolderScanState.Empty:
                        empty++;
                        break;
                }
            }
            catch (Exception ex)
            {
                failed++;
                _logger.LogError(ex, "Id={Id} folder={Folder}: processing failed.", doc.Id, folder);
            }
        }

        _logger.LogInformation(
            "Cycle complete. Processed={Total} Clean={Clean} Malicious={Mal} Unscanned={Uns} Empty={Empty} Failed={Failed}",
            pending.Count, clean, malicious, unscanned, empty, failed);
    }

    /// <summary>
    /// Accepts either a bare folder name (e.g. "AAMkADRj...") or a full blob URL/path,
    /// returning just the top-level folder name relative to the source container.
    /// </summary>
    private static string ExtractFolderName(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return string.Empty;

        // Strip URL scheme/host if present.
        if (Uri.TryCreate(path, UriKind.Absolute, out var uri))
        {
            // Path like /<container>/<folder>/... -> take 2nd segment.
            var segs = uri.AbsolutePath.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
            return segs.Length >= 2 ? segs[1] : string.Empty;
        }

        // Relative form: "<container>/<folder>/..." or just "<folder>" or "<folder>/..."
        var parts = path.Trim().Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 0) return string.Empty;

        // Heuristic: if the first segment matches a known container name, drop it.
        // Otherwise treat the whole first segment as the folder name.
        return parts.Length >= 2 && IsLikelyContainerSegment(parts[0])
            ? parts[1]
            : parts[0];
    }

    private static bool IsLikelyContainerSegment(string s) =>
        s.Equals("email-scanpending", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("email-processed", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("email-staging", StringComparison.OrdinalIgnoreCase);
}
