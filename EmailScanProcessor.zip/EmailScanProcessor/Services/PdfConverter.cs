using iText.Kernel.Pdf;
using Microsoft.Extensions.Logging;
using Syncfusion.Pdf;
using Syncfusion.Pdf.Graphics;

namespace EmailScanProcessor.Services;

public sealed class PdfConverter : IPdfConverter
{
    private readonly ILogger<PdfConverter> _logger;

    public PdfConverter(ILogger<PdfConverter> logger)
    {
        _logger = logger;
    }

    public byte[] ConvertToPdf(byte[] fileContent, string fileName)
    {
        var isPdf = fileName.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase);
        return isPdf
            ? RepairPdfWithItext7(fileContent)
            : ImageToPdfWithSyncfusion(fileContent);
    }

    // PDF input: repair / re-serialise by copying every page into a fresh document.
    // iText 7 equivalent of the legacy iTextSharp PdfReader -> PdfCopy pattern.
    private byte[] RepairPdfWithItext7(byte[] fileContent)
    {
        using var input = new MemoryStream(fileContent);
        using var output = new MemoryStream();

        using (var reader = new PdfReader(input))
        using (var writer = new PdfWriter(output))
        {
            reader.SetUnethicalReading(true); // tolerate slightly malformed PDFs
            using var src = new PdfDocument(reader);
            using var dest = new PdfDocument(writer);
            var pageCount = src.GetNumberOfPages();
            if (pageCount > 0)
            {
                src.CopyPagesTo(1, pageCount, dest);
            }
        }

        return output.ToArray();
    }

    // Non-PDF input: assume image, draw onto a fresh PDF page (matches the existing pattern).
    // PdfBitmap supports PNG, JPG, GIF, BMP, TIFF. Anything else will throw.
    private byte[] ImageToPdfWithSyncfusion(byte[] fileContent)
    {
        using var imageStream = new MemoryStream(fileContent);
        using var pdfDoc = new PdfDocument();

        var page = pdfDoc.Pages.Add();
        var graphics = page.Graphics;
        var pdfImage = new PdfBitmap(imageStream);
        graphics.DrawImage(
            pdfImage,
            0, 0,
            page.GetClientSize().Width,
            page.GetClientSize().Height);

        using var outStream = new MemoryStream();
        pdfDoc.Save(outStream);
        pdfDoc.Close(true);
        return outStream.ToArray();
    }
}
