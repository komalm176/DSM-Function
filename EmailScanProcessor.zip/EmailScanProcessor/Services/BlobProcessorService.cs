using System.IO.Compression;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using EmailScanProcessor.Models;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EmailScanProcessor.Services;

public sealed class BlobProcessorService : IBlobProcessorService
{
    private readonly BlobServiceClient _blobService;
    private readonly IPdfConverter _pdfConverter;
    private readonly ScanProcessorOptions _options;
    private readonly ILogger<BlobProcessorService> _logger;

    public BlobProcessorService(
        BlobServiceClient blobService,
        IPdfConverter pdfConverter,
        IOptions<ScanProcessorOptions> options,
        ILogger<BlobProcessorService> logger)
    {
        _blobService = blobService;
        _pdfConverter = pdfConverter;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<bool> ProcessCleanFolderAsync(
        IReadOnlyList<BlobScanInfo> blobs,
        string folderName,
        CancellationToken ct)
    {
        var destContainer = _blobService.GetBlobContainerClient(_options.DestinationContainer);
        await destContainer.CreateIfNotExistsAsync(cancellationToken: ct);

        var destPrefix = NormalizePrefix(folderName);
        var movedBlobNames = new List<string>(); // for rollback

        foreach (var blob in blobs)
        {
            ct.ThrowIfCancellationRequested();

            var isZip = blob.Item.Name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase);
            var success = isZip
                ? await TryProcessZipBlobAsync(blob, destContainer, destPrefix, movedBlobNames, ct)
                : await TryProcessSingleBlobAsync(blob, destContainer, destPrefix, movedBlobNames, ct);

            if (!success)
            {
                _logger.LogError("Folder {Folder}: failure on {Blob}. Rolling back {Count} uploaded file(s).",
                    folderName, blob.Item.Name, movedBlobNames.Count);
                await RollbackMovedBlobsAsync(destContainer, movedBlobNames, ct);
                return false;
            }
        }

        _logger.LogInformation("Folder {Folder}: processed {Count} source blob(s) -> {Dest}.",
            folderName, blobs.Count, _options.DestinationContainer);
        return true;
    }

    public async Task<bool> QuarantineFolderAsync(
        IReadOnlyList<BlobScanInfo> blobs,
        string folderName,
        CancellationToken ct)
    {
        var quarantineContainer = _blobService.GetBlobContainerClient(_options.QuarantineContainer);
        await quarantineContainer.CreateIfNotExistsAsync(cancellationToken: ct);

        var destPrefix = NormalizePrefix(folderName);
        var movedBlobNames = new List<string>();

        foreach (var blob in blobs)
        {
            ct.ThrowIfCancellationRequested();

            try
            {
                var fileName = Path.GetFileName(blob.Item.Name);
                var destName = destPrefix + fileName;
                var destBlob = quarantineContainer.GetBlobClient(destName);

                await destBlob.SyncCopyFromUriAsync(blob.Client.Uri, cancellationToken: ct);
                await blob.Client.DeleteIfExistsAsync(cancellationToken: ct);
                movedBlobNames.Add(destName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Folder {Folder}: failed to quarantine {Blob}. Rolling back {Count} moved file(s).",
                    folderName, blob.Item.Name, movedBlobNames.Count);
                await RollbackMovedBlobsAsync(quarantineContainer, movedBlobNames, ct);
                return false;
            }
        }

        _logger.LogWarning("Folder {Folder}: quarantined {Count} malicious file(s).",
            folderName, blobs.Count);
        return true;
    }

    // ---------------------------------------------------------------------
    //  ZIP handling
    // ---------------------------------------------------------------------

    private async Task<bool> TryProcessZipBlobAsync(
        BlobScanInfo blob,
        BlobContainerClient destContainer,
        string destPrefix,
        List<string> movedBlobNames,
        CancellationToken ct)
    {
        _logger.LogInformation("ZIP detected - extracting: {Name}", blob.Item.Name);

        using var ms = new MemoryStream();
        try
        {
            await blob.Client.DownloadToAsync(ms, ct);
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Failed to download ZIP blob {Name}.", blob.Item.Name);
            return false;
        }

        ms.Position = 0;

        try
        {
            using var archive = new ZipArchive(ms, ZipArchiveMode.Read);
            foreach (var entry in archive.Entries)
            {
                if (string.IsNullOrEmpty(entry.Name)) continue; // skip directory entries

                var entrySuccess = await TryProcessZipEntryAsync(
                    entry, destContainer, destPrefix, movedBlobNames, ct);

                if (!entrySuccess) return false;
            }
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Failed to extract ZIP blob {Name}.", blob.Item.Name);
            return false;
        }

        // Delete the original zip from staging
        await blob.Client.DeleteIfExistsAsync(cancellationToken: ct);
        return true;
    }

    private async Task<bool> TryProcessZipEntryAsync(
        ZipArchiveEntry entry,
        BlobContainerClient destContainer,
        string destPrefix,
        List<string> movedBlobNames,
        CancellationToken ct)
    {
        byte[] fileBytes;
        await using (var entryStream = entry.Open())
        await using (var entryMs = new MemoryStream())
        {
            await entryStream.CopyToAsync(entryMs, ct);
            fileBytes = entryMs.ToArray();
        }

        byte[] pdfBytes;
        try
        {
            pdfBytes = _pdfConverter.ConvertToPdf(fileBytes, entry.Name);
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Failed to convert ZIP entry {Entry} to PDF.", entry.Name);
            return false;
        }

        var pdfEntryName = Path.GetFileNameWithoutExtension(entry.Name) + ".pdf";
        var uniqueBlobName = await GetUniqueBlobNameAsync(destContainer, destPrefix, pdfEntryName, ct);

        try
        {
            var destBlob = destContainer.GetBlobClient(uniqueBlobName);
            using var pdfStream = new MemoryStream(pdfBytes);
            await destBlob.UploadAsync(pdfStream, overwrite: false, cancellationToken: ct);
            movedBlobNames.Add(uniqueBlobName);

            _logger.LogInformation("Extracted+converted {Entry} -> {Container}/{BlobName}",
                entry.Name, _options.DestinationContainer, uniqueBlobName);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Failed to upload converted ZIP entry {Entry}.", entry.Name);
            return false;
        }
    }

    // ---------------------------------------------------------------------
    //  Single (non-ZIP) blob handling
    // ---------------------------------------------------------------------

    private async Task<bool> TryProcessSingleBlobAsync(
        BlobScanInfo blob,
        BlobContainerClient destContainer,
        string destPrefix,
        List<string> movedBlobNames,
        CancellationToken ct)
    {
        var fileName = Path.GetFileName(blob.Item.Name);

        byte[] fileBytes;
        using (var fileMs = new MemoryStream())
        {
            try
            {
                await blob.Client.DownloadToAsync(fileMs, ct);
                fileBytes = fileMs.ToArray();
            }
            catch (Exception ex)
            {
                _logger.LogCritical(ex, "Failed to download blob {Name}.", blob.Item.Name);
                return false;
            }
        }

        byte[] pdfBytes;
        try
        {
            pdfBytes = _pdfConverter.ConvertToPdf(fileBytes, fileName);
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Failed to convert blob {Name} to PDF.", blob.Item.Name);
            return false;
        }

        var pdfFileName = Path.GetFileNameWithoutExtension(fileName) + ".pdf";
        var uniqueName = await GetUniqueBlobNameAsync(destContainer, destPrefix, pdfFileName, ct);

        try
        {
            var destBlob = destContainer.GetBlobClient(uniqueName);
            using var pdfStream = new MemoryStream(pdfBytes);
            await destBlob.UploadAsync(pdfStream, overwrite: false, cancellationToken: ct);
            movedBlobNames.Add(uniqueName);

            _logger.LogInformation("Converted+moved {Name} -> {Container}/{Dest}",
                blob.Item.Name, _options.DestinationContainer, uniqueName);
        }
        catch (Exception ex)
        {
            _logger.LogCritical(ex, "Failed to upload converted blob {Name}.", blob.Item.Name);
            return false;
        }

        // Delete original from staging
        await blob.Client.DeleteIfExistsAsync(cancellationToken: ct);
        return true;
    }

    // ---------------------------------------------------------------------
    //  Helpers
    // ---------------------------------------------------------------------

    /// <summary>
    /// If destPrefix/preferredFileName already exists in dest container, appends -1, -2, ...
    /// to avoid collisions across runs.
    /// </summary>
    private static async Task<string> GetUniqueBlobNameAsync(
        BlobContainerClient dest,
        string destPrefix,
        string preferredFileName,
        CancellationToken ct)
    {
        var candidate = destPrefix + preferredFileName;
        var nameWithoutExt = Path.GetFileNameWithoutExtension(preferredFileName);
        var ext = Path.GetExtension(preferredFileName);

        var suffix = 0;
        while (await dest.GetBlobClient(candidate).ExistsAsync(ct))
        {
            suffix++;
            candidate = destPrefix + $"{nameWithoutExt}-{suffix}{ext}";
        }
        return candidate;
    }

    private async Task RollbackMovedBlobsAsync(
        BlobContainerClient container,
        List<string> movedBlobNames,
        CancellationToken ct)
    {
        foreach (var name in movedBlobNames)
        {
            try
            {
                await container.GetBlobClient(name).DeleteIfExistsAsync(cancellationToken: ct);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Rollback could not delete {Blob}.", name);
            }
        }
    }

    private static string NormalizePrefix(string folderName)
    {
        var trimmed = folderName.Trim().Trim('/');
        return trimmed.EndsWith('/') ? trimmed : trimmed + "/";
    }
}
