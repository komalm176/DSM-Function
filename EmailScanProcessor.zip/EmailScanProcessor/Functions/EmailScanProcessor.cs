using EmailScanProcessor.Models;
using EmailScanProcessor.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace EmailScanProcessor.Functions;

public sealed class EmailScanProcessor
{
    private readonly IEmailDocumentRepository _repo;
    private readonly IBlobScanService _scan;
    private readonly IBlobProcessorService _processor;
    private readonly ScanProcessorOptions _options;
    private readonly ILogger<EmailScanProcessor> _logger;

    public EmailScanProcessor(
        IEmailDocumentRepository repo,
        IBlobScanService scan,
        IBlobProcessorService processor,
        IOptions<ScanProcessorOptions> options,
        ILogger<EmailScanProcessor> logger)
    {
        _repo = repo;
        _scan = scan;
        _processor = processor;
        _options = options.Value;
        _logger = logger;
    }

    [Function(nameof(EmailScanProcessor))]
    public async Task RunAsync(
        [TimerTrigger("%ScanProcessor:ScheduleCron%")] TimerInfo timer,
        CancellationToken ct)
    {
        _logger.LogInformation("EmailScanProcessor starting. Next: {Next}", timer.ScheduleStatus?.Next);

        var pending = await _repo.GetPendingDocumentsAsync(_options.BatchSize, _options.AgeThresholdHours, ct);
        if (pending.Count == 0)
        {
            _logger.LogInformation("No pending documents this cycle.");
            return;
        }

        var readyForReview = 0;
        var malicious = 0;
        var unscanned = 0;
        var empty = 0;
        var failed = 0;

        foreach (var doc in pending)
        {
            ct.ThrowIfCancellationRequested();

            var folder = ExtractFolderName(doc.EmailAttachmentPath);
            if (string.IsNullOrWhiteSpace(folder))
            {
                _logger.LogWarning("Id={Id}: EmailAttachmentPath '{Path}' could not be parsed.",
                    doc.Id, doc.EmailAttachmentPath);
                failed++;
                continue;
            }

            try
            {
                var result = await _scan.EvaluateFolderAsync(_options.SourceContainer, folder, ct);

                switch (result.State)
                {
                    case FolderScanState.AllClean:
                    {
                        var ok = await _processor.ProcessCleanFolderAsync(result.Blobs, folder, ct);
                        if (ok)
                        {
                            await _repo.UpdateAfterProcessingAsync(
                                doc.Id, EmailStatuses.ReadyForReview, folder, ct);
                            readyForReview++;
                            _logger.LogInformation(
                                "Id={Id} folder={Folder}: processed and marked '{Status}'.",
                                doc.Id, folder, EmailStatuses.ReadyForReview);
                        }
                        else
                        {
                            failed++;
                        }
                        break;
                    }

                    case FolderScanState.AnyMalicious:
                    {
                        var ok = await _processor.QuarantineFolderAsync(result.Blobs, folder, ct);
                        if (ok)
                        {
                            await _repo.UpdateAfterProcessingAsync(
                                doc.Id, EmailStatuses.Malicious, folder, ct);
                            malicious++;
                            _logger.LogWarning(
                                "Id={Id} folder={Folder}: quarantined and marked '{Status}'.",
                                doc.Id, folder, EmailStatuses.Malicious);
                        }
                        else
                        {
                            failed++;
                        }
                        break;
                    }

                    case FolderScanState.AnyUnscanned:
                        unscanned++;
                        // Leave as ScanPending; revisit next cycle.
                        break;

                    case FolderScanState.Empty:
                        empty++;
                        _logger.LogWarning("Id={Id} folder={Folder}: folder is empty.", doc.Id, folder);
                        break;
                }
            }
            catch (Exception ex)
            {
                failed++;
                _logger.LogError(ex, "Id={Id} folder={Folder}: processing failed.", doc.Id, folder);
            }
        }

        _logger.LogInformation(
            "Cycle complete. Total={Total} ReadyForReview={Rfr} Malicious={Mal} Unscanned={Uns} Empty={Empty} Failed={Failed}",
            pending.Count, readyForReview, malicious, unscanned, empty, failed);
    }

    private static string ExtractFolderName(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return string.Empty;

        if (Uri.TryCreate(path, UriKind.Absolute, out var uri))
        {
            var segs = uri.AbsolutePath.Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
            return segs.Length >= 2 ? segs[1] : string.Empty;
        }

        var parts = path.Trim().Trim('/').Split('/', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 0) return string.Empty;

        return parts.Length >= 2 && IsLikelyContainerSegment(parts[0])
            ? parts[1]
            : parts[0];
    }

    private static bool IsLikelyContainerSegment(string s) =>
        s.Equals("email-scanpending", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("email-processed", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("email-quarantine", StringComparison.OrdinalIgnoreCase) ||
        s.Equals("email-staging", StringComparison.OrdinalIgnoreCase);
}
