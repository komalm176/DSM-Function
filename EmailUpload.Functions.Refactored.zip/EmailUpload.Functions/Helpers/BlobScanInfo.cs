using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace EmailUpload.Functions.Helpers
{
    /// <summary>
    /// Internal model to hold per-blob scan details read from blob metadata.
    /// </summary>
    internal record BlobScanInfo(
        BlobClient Client,
        BlobItem   Item,
        string?    ScanResult,
        int        RetryCount);
}
